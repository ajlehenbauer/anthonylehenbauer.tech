        //var i = 0;
        //var txt = 'Lorem ipsum dummy text blabla.';
        var speed = 50;
        var scrollCount=1;
        var el;
        window.onload=function(){
            el = document.getElementById("image2");
            fadeOut();
            
          }
        
        
        
          function fadeIn(){
            el.classList.remove('fade-out');
            el.classList.remove('hidden');
            void el.offsetWidth;
            el.classList.add('fade-in'); 
            setTimeout(function(){fadeOut();}, 4000);
          }
          function fadeOut(){
            el.classList.remove('fade-in');
            
            void el.offsetWidth;
            el.classList.add('fade-out'); 
            el.classList.add('hidden');
            setTimeout(function(){fadeIn();}, 4000);
          }


        