//var i = 0;
//var txt = 'Lorem ipsum dummy text blabla.';
var speed = 50;
var scrollCount=1;
var el;
var plugnum;
var tryCount = 0;
var plugged1;
var plugged2;
var plugged3;
var powered=false;
var startPos;
var plug1top=50;
var plug2top=50;
var plug3top=50;
var event;


window.addEventListener('resize', function(){
  document.getElementById("plug1").style.top = document.getElementById("main").clientHeight+document.getElementById("main").getBoundingClientRect().top+plug1top;
  document.getElementById("plug2").style.top = document.getElementById("main").clientHeight+document.getElementById("main").getBoundingClientRect().top+plug2top;
  document.getElementById("plug3").style.top = document.getElementById("main").clientHeight+document.getElementById("main").getBoundingClientRect().top+plug3top;
  document.getElementById("powerbutton").style.top = document.getElementById("main").clientHeight+document.getElementById("main").getBoundingClientRect().top-(window.innerHeight*.01);
  document.getElementById("powerbutton").style.height = (window.innerWidth*.015);


});

window.onload=function(){
    
  plugNum = 0;
  el = document.getElementById("power");
  
  document.getElementById("powerbutton").addEventListener("click",function(){
    
    console.log(el.src)
    if(powered){
      el.src = "powerOff.png";
      powered=!powered;
      document.getElementById('light').src = "empty.png";
    }
    else{
      el.src = "powerOn.png";
      powered=!powered;
      powerUp(0);
    }
    

  });

  document.getElementById("plug1").style.top = document.getElementById("main").clientHeight+document.getElementById("main").getBoundingClientRect().top+plug1top;
  document.getElementById("plug2").style.top = document.getElementById("main").clientHeight+document.getElementById("main").getBoundingClientRect().top+plug2top;
  document.getElementById("plug3").style.top = document.getElementById("main").clientHeight+document.getElementById("main").getBoundingClientRect().top+plug3top;
  document.getElementById("powerbutton").style.top = document.getElementById("main").clientHeight+document.getElementById("main").getBoundingClientRect().top-(window.innerHeight*.01);
  document.getElementById("powerbutton").style.height = (window.innerWidth*.015);
}

function dragPlug(num){
  
  if(num!=0 && mouseEvent.clientY!=null){
    var t = startPos-mouseEvent.pageY;
    var plug = document.getElementById('plug'+num);
    t = Math.max(minTop,t);
    t = Math.min(maxTop,t);
    plug.style.top = ''+t+'%';
  }
  
} 
  
function setPlug(number){
  
  
    if(number == 1){
      if(plug1top<0){
        plugged1=false;
        plug1top = 50;
      }
      else{
        plugged1=true;
        plug1top = -25;
      }
      
    }
    else if(number == 2){
      if(plug2top<0){
        plugged2=false;
        plug2top = 50;
      }
      else{
        plugged2=true;
        plug2top = -25;
      }
    }
    else if(number == 3){
      if(plug3top<0){
        plugged3=false;
        plug3top = 50;
        document.getElementById('light').src = "empty.png";
      }
      else{
        
        plugged3=true;
        if(powered){
          powerUp(0);
        }
        plug3top = -25;
      }
    }
    document.getElementById("plug1").style.top = document.getElementById("main").clientHeight+document.getElementById("main").getBoundingClientRect().top+plug1top;
    document.getElementById("plug2").style.top = document.getElementById("main").clientHeight+document.getElementById("main").getBoundingClientRect().top+plug2top;
    document.getElementById("plug3").style.top = document.getElementById("main").clientHeight+document.getElementById("main").getBoundingClientRect().top+plug3top;
  
  
}
function powerUp(i){
  if(plugged3&&powered){
    switch(i){
      case(0):
        document.getElementById('light').src = "lightOne.png";
        break;
      case(1):
        document.getElementById('light').src = "lightTwo.png";
        break;
      case(2):
        document.getElementById('light').src = "lightThree.png";
        break;
      case(3):
        document.getElementById('light').src = "lightFour.png";
        break;
      case(4):
        tryCount++;
        if(plugged1&&plugged2&&plugged3){
          document.getElementById('light').src = "successLight.png";
          setTimeout(function(){powerBlinkBad(0);}, 3000);
          break;
        }
        else{
          document.getElementById('light').src = "failLight.png";
          break;
        }
    }
    if(i<5){
      setTimeout(function(){powerUp(i+1);}, 1000);
    }
    
    
  }
  else{
    document.getElementById('light').src = "empty.png";
  }
  
}

function powerBlinkBad(i){
  if(plugged3&&powered){
    if(i%2==0){
      document.getElementById('light').src = "successLight.png";
    }
    else{
      document.getElementById('light').src = "failLight.png";
    }
    console.log('blink');
    if(i<7){
      setTimeout(function(){powerBlinkBad(i+1);}, 500);
    }
  }
  else{
    document.getElementById('light').src = "empty.png";
  }
}


function releasePlug(){
  plugnum=0;
}


  function fadeIn(){
    el.classList.remove('fade-out');
    el.classList.remove('hidden');
    void el.offsetWidth;
    el.classList.add('fade-in'); 
    setTimeout(function(){fadeOut();}, 4000);
  }
  function fadeOut(){
    el.classList.remove('fade-in');
    
    void el.offsetWidth;
    el.classList.add('fade-out'); 
    el.classList.add('hidden');
    setTimeout(function(){fadeIn();}, 4000);
  }


        