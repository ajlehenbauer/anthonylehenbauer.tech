        //var i = 0;
        //var txt = 'Lorem ipsum dummy text blabla.';
        var speed = 50;
        var scrollCount=1;
        function typeWriter(txt,i) {
        if (i < txt.length) {
            document.getElementById("demo").innerHTML += txt.charAt(i);
            i++;
            setTimeout(function(){typeWriter(txt,i);}, 100);
        }
        }
        function switchImage(id) {
            
            document.getElementById(id).src = "3.png";
                
            
        }
        function fadein(id) {
        
            document.getElementById(id).className = "panel fade-in";
            document.getElementById('changemebutton').className = "hidden";

        }
        function nextPic() {
            if(scrollCount==2){
                document.getElementById('image1').style.backgroundImage  = "url('1.png')";
                document.getElementById('image2').style.backgroundImage  = "url('2.png')";
                document.getElementById('image3').style.backgroundImage  = "url('3.png')";
                document.getElementById('image4').style.backgroundImage  = "url('1.png')";
                scrollCount++;
            }
            else if(scrollCount==3){
                document.getElementById('image1').style.backgroundImage  = "url('2.png')";
                document.getElementById('image2').style.backgroundImage  = "url('3.png')";
                document.getElementById('image3').style.backgroundImage  = "url('1.png')";
                document.getElementById('image4').style.backgroundImage  = "url('2.png')";
                scrollCount++;
            }
            else{
                document.getElementById('image1').style.backgroundImage  = "url('3.png')";
                document.getElementById('image2').style.backgroundImage  = "url('1.png')";
                document.getElementById('image3').style.backgroundImage  = "url('2.png')";
                document.getElementById('image4').style.backgroundImage  = "url('3.png')";
                scrollCount=2;
            }
            document.getElementById('image1').classList.remove("image1");
            void document.getElementById('image1').offsetWidth;
            document.getElementById('image1').classList.add("image1");
            document.getElementById('image2').classList.remove("image2");
            void document.getElementById('image2').offsetWidth;
            document.getElementById('image2').classList.add("image2");
            document.getElementById('image3').classList.remove("image3");
            void document.getElementById('image3').offsetWidth;
            document.getElementById('image3').classList.add("image3");
            document.getElementById('image4').classList.remove("image4");
            void document.getElementById('image4').offsetWidth;
            document.getElementById('image4').classList.add("image4");
        }

        