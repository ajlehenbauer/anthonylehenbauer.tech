

var speed = 1.3;
var mx;
var my;

window.onload=function(){
    
    createFly();

    
}

function coordinate(event){
    mx = event.clientX; 
    my = event.clientY; 
     
}

function animateJar(i, jar){
    
    if(i==1){
        jar = document.createElement('div');
        jar.className = 'jar';
        document.body.appendChild(jar);
        jar.style.top =my-32;
        jar.style.left =mx-32;
        jar.appendChild(document.createElement('img'));
        jar.getElementsByTagName('img')[0].className = "jar-img";
        jar.getElementsByTagName('img')[0].src = ""+i+".png";
        jar.style.width = 80;
        jar.style.height = 80;
        setTimeout(function(){animateJar(i+1,jar)},125);
        return jar;
    }
    else if(i<5){
        
        jar.getElementsByTagName('img')[0].src = ""+i+".png";
        setTimeout(function(){animateJar(i+1,jar)},125);
    }
    else{
        dropJar(jar);
    }
    
    
    
}
function createFly(){
    var el = document.createElement('img');
    el.className = 'fly';
    el.src = "fly.png";
    document.body.appendChild(el);
    el.style.top ="" + Math.floor(Math.random()*window.innerHeight);
    el.style.left ="" + Math.floor(Math.random()*window.innerWidth);
    el.addEventListener("click",function(){
        if(el.className != 'fly-caught'){
            createFly();
            el.className = 'fly-caught';
            mx = el.offsetLeft; 
            my = el.offsetTop;
            el.style.top = 25;
            el.style.left = 22.5;
            animateJar(1,null).appendChild(el);
        }
    });
    flyAround(el,Math.random()*(document.body.clientWidth-document.body.clientWidth*.20)+document.body.clientWidth*.10,
    Math.random()*(document.body.clientHeight-document.body.clientHeight*.20)+document.body.clientHeight*.10,1,20,0);
}

function dropJar(jar){
    
    if(jar.offsetTop<document.body.clientHeight-85){
        jar.style.top = jar.offsetTop+2;
        setTimeout(function(){dropJar(jar)},10);
    }
}
function hover(element,d,c,i){
    element.style.top=element.offsetTop+(speed*d);
    c-=speed;
    if(element.className == 'fly-caught'){
        flyAround(element,0,0,1,0,0);
    }
    else if(i>3){
        flyAround(element,Math.random()*(document.body.clientWidth-document.body.clientWidth*.20)+document.body.clientWidth*.10,
            Math.random()*(document.body.clientHeight-document.body.clientHeight*.20)+document.body.clientHeight*.10,1,20,0);
    }
    else if(c<0){
        setTimeout(function(){hover(element,-d,30,i+1);},100); 
    }
    else{
        setTimeout(function(){hover(element,d,c,i);},100);  
    }
}


function flyAround(element,x, y,d,c,cs){
    
    if(element.className == 'fly'){
          
        if(Math.abs(element.offsetLeft-x)<1){
            hover(element,1,30,0);
            return null;
          }
        else if(element.offsetLeft<x){
              
            element.style.left=(speed+element.offsetLeft);
          }
          else if(element.offsetLeft>x){
            
              element.style.left=(element.offsetLeft-speed);
          }
          
          element.style.top=element.offsetTop+((speed*d*Math.min(c,cs))/20);
          cs+=speed;
          c-=speed;

          if(c<0){
            c=Math.random()*30+25;
            cs=0;
              if(element.offsetTop<y){
                  if(Math.random()<.25){
                      d=-1;
                  }
                  else{
                      d=1;
                  }

              }
              else{
                if(Math.random()<.25){
                    d=1;
                }
                else{
                    d=-1;
                }
              }
          }
          setTimeout(function(){flyAround(element,x,y,d,c,cs);},30); 
    }
    else if(element.className == 'fly-caught'){
        
        element.style.top=element.offsetTop+(speed*d);
        if(element.offsetTop<30||element.offsetTop>40){
            setTimeout(function(){flyAround(element,x,y,-d,c,cs);},100); 
        }
        else{
            setTimeout(function(){flyAround(element,x,y,d,c,cs);},100); 
        }
    }
}