        //var i = 0;
        //var txt = 'Lorem ipsum dummy text blabla.';
        var speed = 50;
        
        function typeWriter(txt,i) {
        if (i < txt.length) {
            document.getElementById("demo").innerHTML += txt.charAt(i);
            i++;
            setTimeout(function(){typeWriter(txt,i);}, 100);
        }
        }
        function switchImage(id) {
            
                document.getElementById(id).src = "3.png";
                
            
        }
        function fadein(id) {
            
            document.getElementById(id).className = "panel fade-in";
            document.getElementById('changemebutton').className = "hidden";
            
        
        }