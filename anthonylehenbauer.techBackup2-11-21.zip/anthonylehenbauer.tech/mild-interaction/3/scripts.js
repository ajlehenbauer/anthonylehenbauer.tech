        //var i = 0;
        //var txt = 'Lorem ipsum dummy text blabla.';
        var speed = 50;
        var scrollCount=1;
        
        window.onload=function(){
            
            
                var el2 = document.getElementById('image2');
                var el3 = document.getElementById('image3');
                var el4 = document.getElementById('image4');
                var el5 = document.getElementById('image5');
                if(el2){
                    el2.addEventListener("mouseover", 
                    function(){
                        el2.classList.remove('fade-out');
                        el2.classList.remove('hidden');
                        void el2.offsetWidth;
                        el2.classList.add('fade-in'); 
                        
                    });
                    el2.addEventListener("mouseout", 
                    function(){
                        el2.classList.remove('fade-in');
                         void el2.offsetWidth;
                         el2.classList.add('fade-out');
                         el2.classList.add('hidden'); 
                        
                    });
                    el2.addEventListener("click", 
                    function(){
                        el2.classList.remove('fade-out');
                         void el2.offsetWidth;
                         el2.classList.add('fade-out');
                         el2.classList.add('hidden'); 
                        
                    });
                }
                if(el3){
                    el3.addEventListener("mouseover", 
                    function(){
                        el3.classList.remove('fade-out');
                        el3.classList.remove('hidden');
                        void el3.offsetWidth;
                        el3.classList.add('fade-in');  
                    });
                    el3.addEventListener("mouseout", 
                    function(){
                        el3.classList.remove('fade-in');
                         void el3.offsetWidth;
                         el3.classList.add('fade-out');
                         el3.classList.add('hidden'); 
                    });
                    el3.addEventListener("click", 
                    function(){
                        el2.classList.remove('fade-out');
                         void el2.offsetWidth;
                         el2.classList.add('fade-out');
                         el2.classList.add('hidden'); 
                        
                    });
                }
                if(el4){
                    el4.addEventListener("mouseover", 
                    function(){
                        el4.classList.remove('fade-out');
                        el4.classList.remove('hidden');
                        void el4.offsetWidth;
                        el4.classList.add('fade-in');  
                    });
                    el4.addEventListener("mouseout", 
                    function(){
                        el4.classList.remove('fade-in');
                         void el4.offsetWidth;
                         el4.classList.add('fade-out');
                         el4.classList.add('hidden'); 
                    });
                    el4.addEventListener("click", 
                    function(){
                        el2.classList.remove('fade-out');
                         void el2.offsetWidth;
                         el2.classList.add('fade-out');
                         el2.classList.add('hidden'); 
                        
                    });
                }
                if(el5){
                    el5.addEventListener("mouseover", 
                    function(){
                        el5.classList.remove('fade-out');
                        el5.classList.remove('hidden');
                        void el5.offsetWidth;
                        el5.classList.add('fade-in');  
                    });
                    el5.addEventListener("mouseout", 
                    function(){
                        el5.classList.remove('fade-in');
                         void el5.offsetWidth;
                         el5.classList.add('fade-out');
                         el5.classList.add('hidden'); 
                    });
                    el5.addEventListener("click", 
                    function(){
                        el2.classList.remove('fade-out');
                         void el2.offsetWidth;
                         el2.classList.add('fade-out');
                         el2.classList.add('hidden'); 
                        
                    });
                }
            
            
        
          }
        
        
        




        function typeWriter(txt,i) {
        if (i < txt.length) {
            document.getElementById("demo").innerHTML += txt.charAt(i);
            i++;
            setTimeout(function(){typeWriter(txt,i);}, 100);
        }
        }
        function switchImage(id) {
            
            document.getElementById(id).src = "3.png";
                
            
        }
        function fadein(id) {
        
            document.getElementById(id).className = "panel fade-in";
            document.getElementById('changemebutton').className = "hidden";

        }
        